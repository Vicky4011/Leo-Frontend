import { Assistant } from '@/components/assistant';

export default function Home() {
  return (
    <main
      style={{
        minHeight: '100vh',
        display: 'grid',
        placeItems: 'center',
        background:
          'radial-gradient(circle at center, rgba(35, 65, 150, 0.16), transparent 38%), #05070d',
      }}
    >
      <Assistant />
    </main>
  );
}
