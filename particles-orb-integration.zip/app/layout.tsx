import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Particles Orb',
  description: 'Particles Orb integration',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
